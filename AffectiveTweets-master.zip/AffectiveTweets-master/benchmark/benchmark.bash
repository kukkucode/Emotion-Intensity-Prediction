bash nltk.bash
bash affectivetweets.bash
