## How to Contribute

New contributors are more than welcome. If you want to contribute just fork the project and send a [pull request](https://help.github.com/articles/about-pull-requests/) with your changes. 

More details about how to contribute are given [here](https://affectivetweets.cms.waikato.ac.nz/contribute/).