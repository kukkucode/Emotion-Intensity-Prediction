### Description

#### Expected behavior:

#### Encountered behavior:


### Additional Information

- Weka version:
- AffectiveTweets version:
- Operating System:
